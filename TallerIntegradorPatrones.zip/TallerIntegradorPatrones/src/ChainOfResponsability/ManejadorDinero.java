/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChainOfResponsability;

public class ManejadorDinero implements Manejador
{
    protected int monto;
    protected int denominacion;
    protected Manejador next;

    public ManejadorDinero(int monto, int denominacion){
         Manejador(monto, denominacion);
    }

    public int getMonto(){ return monto; }
    public int getDenominacion(){ return denominacion; }
    public void setMonto(int monto){ this.monto = monto; }

    @Override
    public boolean retirar(int monto){
        if(monto <= 0)
            return false;
        else if(monto >= this.monto){
            monto-=this.monto;
            this.monto--;
        }
        else
            setNext(next);
        
        if (monto !=0)
            return true;
        else
            return false;
    }    

    @Override
    public boolean depositar(int monto, int denominacion){
        // Implementar
        return false;
    }

    @Override
    public void Manejador(int n, int denominacion) {
        this.monto = monto; // Total de billetes
        this.denominacion = denominacion; // Valor de cada billete
    }

    @Override
    public void setNext(ChainOfResponsability.Manejador manejador) {
       this.next=manejador;
    }
}