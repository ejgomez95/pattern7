/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ChainOfResponsability;

/**
 *
 * @author CltControl
 */
public interface Manejador {
    public void Manejador( int n, int denominacion);
    public void setNext(Manejador manejador);
    public boolean retirar(int monto);
    public boolean depositar(int n, int denominacion); 
    
    
    
    
    
}
